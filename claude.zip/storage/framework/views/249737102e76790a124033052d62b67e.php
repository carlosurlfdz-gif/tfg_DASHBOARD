 

<?php $__env->startSection('content'); ?> 


<!-- NAVBAR -->

<div class="bg-slate-800">

<div class="max-w-7xl mx-auto px-6 py-4 flex justify-between items-center">

<div class="flex items-center gap-8">

<h1 class="font-bold text-lg text-red-400">
SIEM SCALE PROJECT
</h1>

<a href="<?php echo e(url('/dashboard')); ?>" class="text-red-400 border-b border-red-400 pb-1">Dashboard</a>
<a href="<?php echo e(url('/alertas')); ?>" class="text-gray-300">Alertas</a>
<a class="text-gray-300">Logs</a>

</div>

<div class="flex items-center gap-6">

<button class="bg-green-600 px-3 py-1 rounded text-sm">
VPN
</button>

<span>Admin</span>

</div>

</div>

</div>



<div class="max-w-7xl mx-auto px-6 py-8 space-y-6">

<!-- STATS -->
<div class="grid grid-cols-4 gap-6">

    <?php $__currentLoopData = $tipo_alertas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $severity => $count): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="bg-slate-800 p-6 rounded-xl">
            <p class="text-<?php echo e($severity == 1 ? 'red' : ($severity == 2 ? 'yellow' : ($severity == 3 ? 'blue' : 'green'))); ?>-400 text-sm">
                <?php echo e($severity == 1 ? 'CRÍTICAS' : ($severity == 2 ? 'ALTAS' : ($severity == 3 ? 'MEDIAS' : 'BAJAS'))); ?>

            </p>
            <h2 class="text-4xl font-bold mt-2"><?php echo e($count); ?></h2>
            <?php if($diferencia_alertas[$severity]>=0): ?>
                <p class="text-green-400 text-sm mt-2">
                    +<?php echo e($diferencia_alertas[$severity]); ?> hoy
                </p>
            <?php else: ?>
                <p class="text-red-400 text-sm mt-2">
                    <?php echo e($diferencia_alertas[$severity]); ?> hoy
                </p>
            <?php endif; ?>
        </div>  
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</div>

<!-- TRAFICO -->

<div class="bg-slate-800 p-6 rounded-xl">

<div class="flex justify-between mb-6">

<h2 class="font-semibold text-lg">
TRÁFICO DE RED (Últimas 24h)
</h2>

<span class="text-sm text-gray-400">
24h
</span>

</div>

<canvas id="trafficChart" height="110"></canvas>

</div>



<!-- TOP ATACANTES + ALERTAS -->
<div class="grid grid-cols-3 gap-6">

    <!-- TOP ATACANTES -->
    <div class="col-span-2 bg-slate-800 p-6 rounded-xl">

        <h2 class="font-semibold mb-6">
            TOP 5 IP ATACANTES
        </h2>

        <div class="space-y-5 text-sm">
            <?php $__currentLoopData = $top_ips; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ip): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div>
                    <div class="flex justify-between mb-1">
                        <span><?php echo e($ip->src_ip); ?></span>
                        <span class="text-gray-400"><?php echo e($ip->total); ?> ataques</span>
                    </div>

                    <div class="bg-gray-700 h-2 rounded">
                        <div class="bg-red-500 h-2 rounded w-[90%]"></div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

    </div>

    <!-- ALERTAS POR TIPO -->
    <div class="bg-slate-800 p-6 rounded-xl">

        <h2 class="font-semibold mb-4">
            ALERTAS POR TIPO
        </h2>

        <canvas id="alertChart"></canvas>

        <div class="mt-4 space-y-2 text-sm">
            <?php
                $colores = ['#ef4444','#f59e0b','#3b82f6','#22c55e'];
            ?>

            <?php $__currentLoopData = $alertas_tipos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoria => $total): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="flex justify-between">
                    <span class="flex items-center gap-2">
                        <span class="w-3 h-3 rounded-full"
                              style="background-color: <?php echo e($colores[$loop->index % count($colores)]); ?>;">
                        </span>
                        <?php echo e($categoria); ?>

                    </span>
                    <span><?php echo e($portencajes[$categoria]); ?>%</span>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

    </div>

</div>

<!-- ALERTAS TIEMPO REAL -->
<div class="bg-slate-800 p-6 rounded-xl">

    <h2 class="font-semibold mb-6">
        ÚLTIMAS ALERTAS EN TIEMPO REAL
    </h2>

    <div class="space-y-4">
        <?php $__currentLoopData = $ultimas_alertas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $alerta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <div class="bg-<?php echo e($alerta->severity == 1 ? 'red' : ($alerta->severity == 2 ? 'yellow' : ($alerta->severity == 3 ? 'blue' : 'green'))); ?>-900/30 
                        border border-<?php echo e($alerta->severity == 1 ? 'red' : ($alerta->severity == 2 ? 'yellow' : ($alerta->severity == 3 ? 'blue' : 'green'))); ?>-500 
                        p-4 rounded">

                <p class="text-<?php echo e($alerta->severity == 1 ? 'red' : ($alerta->severity == 2 ? 'yellow' : ($alerta->severity == 3 ? 'blue' : 'green'))); ?>-400 text-sm">
                    
                    <?php echo e($prioridades[$alerta->severity]); ?>

                </p>

                <p class="mt-1">
                    <?php echo e($alerta->categoria); ?>

                </p>

                <p class="text-sm text-gray-400 mt-1">
                    Origen: <?php echo e($alerta->src_ip); ?> → <?php echo e($alerta->dest_ip); ?>

                </p>

            </div>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

</div>

<script>

const ctx = document.getElementById('trafficChart');

new Chart(ctx,{
type:'line',
data:{
//labels:['00','02','04','06','08','10','12','14','16','18','20','22','24'],
labels:[
    <?php $__currentLoopData = $horas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hora): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        '<?php echo e($hora); ?>',
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
],
datasets:[{
//data:[120,180,150,300,450,520,650,820,700,550,420,300, 200],
data:[
    <?php $__currentLoopData = $accesos_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $acceso): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php echo e($acceso); ?>,
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
],
borderColor:'#3b82f6',
tension:0.4
}]
},
options:{
plugins:{legend:{display:false}},
scales:{
x:{ticks:{color:"white"}},
y:{ticks:{color:"white"}}
}
}
});


const ctx2 = document.getElementById('alertChart');

new Chart(ctx2,{
type:'doughnut',
data:{
//labels:['Port Scan','Brute Force','Malware','DDoS'],
labels:[
    <?php $__currentLoopData = $alertas_tipos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tipo => $count): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        '<?php echo e($tipo); ?>',
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
],
datasets:[{
data:[
    <?php $__currentLoopData = $alertas_tipos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tipo => $count): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php echo e($count); ?>,
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
],
backgroundColor:[
'#ef4444',
'#f59e0b',
'#3b82f6',
'#22c55e'
]
}]
},
options:{
plugins:{legend:{display:false}}
}
});

</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('base', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\tfg\resources\views/dashboard.blade.php ENDPATH**/ ?>