<!DOCTYPE html>
<html lang="es">
<head>

<meta charset="UTF-8">
<title>SIEM SCALE PROJECT</title>

<script src="https://cdn.tailwindcss.com"></script>
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

</head>

<body class="bg-slate-900 text-white">

<?php echo $__env->yieldContent('content'); ?> 



</body>
</html><?php /**PATH C:\xampp\htdocs\tfg\resources\views/base.blade.php ENDPATH**/ ?>